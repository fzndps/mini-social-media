// Handel Login Form
const loginForm = document.getElementById('loginForm');
if (loginForm) {
    loginForm.addEventListener('submit', function (e) {
        e.preventDefault();

        const passwordInput = document.getElementById('loginPassword');
        const passwordError = document.getElementById('loginPasswordError');

        let isValid = true;

        // Password Validasi
        if (passwordInput.value.length < 6) {
            passwordError.classList.remove('hidden');
            isValid = false;
        } else {
            passwordError.classList.add('hidden');
        }

        if (isValid) {
            alert('Login sukses!');
        }
    });
}

// Handle Register Form
const registerForm = document.getElementById('registerForm');
if (registerForm) {
    registerForm.addEventListener('submit', function (e) {
        e.preventDefault();

        const passwordInput = document.getElementById('registerPassword');
        const passwordError = document.getElementById('registerPasswordError');

        let isValid = true;

        // Password Validation
        if (passwordInput.value.length < 6) {
            passwordError.classList.remove('hidden');
            isValid = false;
        } else {
            passwordError.classList.add('hidden');
        }

        if (isValid) {
            alert('Register sukses!');
        }
    });
}